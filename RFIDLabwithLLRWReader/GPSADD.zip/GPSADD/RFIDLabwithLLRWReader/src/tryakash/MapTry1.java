package tryakash;

import processing.core.PApplet;
import de.fhpotsdam.unfolding.UnfoldingMap;
import de.fhpotsdam.unfolding.utils.MapUtils;
import de.fhpotsdam.unfolding.providers.*;
import de.fhpotsdam.unfolding.providers.Google.*;

import java.util.List;
import de.fhpotsdam.unfolding.data.Feature;
import de.fhpotsdam.unfolding.data.GeoJSONReader;

import java.util.HashMap;

import de.fhpotsdam.unfolding.marker.Marker;

/**
 * Visualizes life expectancy in different countries.
 * 
 * It loads the country shapes from a GeoJSON file via a data reader, and loads
 * the population density values from another CSV file (provided by the World
 * Bank). The data value is encoded to transparency via a simplistic linear
 * mapping.
 */
public class MapTry1 extends PApplet {

    UnfoldingMap map;
    HashMap<String, Float> lifeExpMap;
    List<Feature> countries;
    List<Marker> countryMarkers;

    public void setup() {
        size(800, 600, OPENGL);
        map = new UnfoldingMap(this, 50, 50, 700, 500, new Google.GoogleMapProvider());
        MapUtils.createDefaultEventDispatcher(this, map);

        // Load lifeExpectancy data
        lifeExpMap = loadLifeExpectancyFromCSV("LifeExpectancyWorldBankModule3.csv");
        println("Loaded " + lifeExpMap.size() + " data entries");

        // Load country polygons and adds them as markers
        countries = GeoJSONReader.loadData(this, "countries_copy.geo2.json");
        countryMarkers = MapUtils.createSimpleMarkers(countries);
        map.addMarkers(countryMarkers);

        // Country markers are shaded according to life expectancy (only once)
        shadeCountries();
    }

    public void draw() {
        // Draw map tiles and country markers
        map.draw();
    }

    // Helper method to color each country based on life expectancy
    // Red-orange indicates low (near 40)
    // Blue indicates high (near 100)
    private void shadeCountries() {
        for (Marker marker : countryMarkers) {
            // Find data for country of the current marker
            String countryId = marker.getId();
            if (lifeExpMap.containsKey(countryId)) {
                float lifeExp = lifeExpMap.get(countryId);
                // Encode value as brightness (values range: 40-90)
                int colorLevel = (int) map(lifeExp, 40, 90, 10, 255);
                marker.setColor(color(255 - colorLevel, 100, colorLevel));
            } else {
                marker.setColor(color(150, 150, 150));
            }
        }
    }

    // Helper method to load life expectancy data from file
    private HashMap<String, Float> loadLifeExpectancyFromCSV(String fileName) {
        HashMap<String, Float> lifeExpMap = new HashMap<String, Float>();

        String[] rows = loadStrings(fileName);
        for (String row : rows) {
            // Reads country name and population density value from CSV row
            // NOTE: Splitting on just a comma is not a great idea here, because
            // the csv file might have commas in their entries, as this one
            // does.
            // We do a smarter thing in ParseFeed, but for simplicity,
            // we just use a comma here, and ignore the fact that the first
            // field is split.
            String[] columns = row.split(",");
            if (columns.length == 6 && !columns[5].equals("..")) {
                lifeExpMap.put(columns[4], Float.parseFloat(columns[5]));
            }
        }

        return lifeExpMap;
    }

}

//package tryakash;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import de.fhpotsdam.unfolding.UnfoldingMap;
//import de.fhpotsdam.unfolding.data.Feature;
//import de.fhpotsdam.unfolding.data.GeoJSONReader;
//import de.fhpotsdam.unfolding.marker.Marker;
//import de.fhpotsdam.unfolding.providers.Google;
//import de.fhpotsdam.unfolding.utils.MapUtils;
//import processing.core.*;
//public class MapTry1 extends PApplet {
//	UnfoldingMap map;
//	 
//	Map<String, Float> lifeExpByCountry;
//	List<Feature> countries;
//	List<Marker> countryMarkers;
//	
//	
//	private Map<String, Float> loadLifeExpectancyFromCSV(String fileName)
//	{
//		Map<String, Float> lifeExpMap = new HashMap<String, Float>();
//		String rows[] = loadStrings(fileName);
//		for(String row: rows){
//			String [] columns = row.split(",");
//			if(columns!=null){
//				float value = Float.parseFloat(columns[5]);
//				lifeExpMap.put(columns[4], value); //columns actually start from 1
//			}
//				
//			
//		}
//		return lifeExpMap;
//	}
//	
//	private void shadeCountries(){
//		for(Marker marker : countryMarkers){
//			String countryId = marker.getId();
//			if(lifeExpByCountry.containsKey(countryId)){
//				float lifeExp = lifeExpByCountry.get(countryId);
//				int colorLevel = (int) map(lifeExp, 40,90,10,255);
//				marker.setColor(color(255-colorLevel, 100, colorLevel));
//				
//			}
//			else{
//				marker.setColor(color(150,150,150));
//			}
//		}
//		
//	}
//	
//	
//	public void setup()
//	{
//		size(800,600, OPENGL);
//		map = new UnfoldingMap(this, 50, 50, 700, 500,new Google.GoogleMapProvider());
//		
//		MapUtils.createDefaultEventDispatcher(this, map);
//		lifeExpByCountry = loadLifeExpectancyFromCSV("/Users/akash/Documents/eclipseWorkspace/UCSDUnfoldingMaps/data/LifeExpectancyWorldBankModule3.csv");
//		//System.out.println(lifeExpByCountry);
//		countries = GeoJSONReader.loadData(this, "/Users/akash/Documents/eclipseWorkspace/UCSDUnfoldingMaps/data/countries.geo.json");
//		countryMarkers = MapUtils.createSimpleMarkers(countries);
//		map.addMarkers(countryMarkers);
//		shadeCountries();
//		
//		
//	}
//	public void draw()
//	{
//		map.draw();
//		
//	}
//
//}
